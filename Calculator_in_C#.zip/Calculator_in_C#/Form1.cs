﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator_in_C_
{
    public partial class Calculator : Form
    {
        string input = string.Empty;
        string num1 = string.Empty;
        string num2 = string.Empty;
        char operation;
        double answer = 0.0;
        int numCount = 0;
        public Calculator()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void One_Click(object sender, EventArgs e)
        {
            input += 1;
            showInput();
        }
        private void two_Click(object sender, EventArgs e)
        {
            input += 2;
            showInput();
        }
        private void three_Click(object sender, EventArgs e)
        {
            input += 3;
            showInput();
        }

        private void Five_Click(object sender, EventArgs e)
        {
            input += 5;
            showInput();
        }

        private void six_Click(object sender, EventArgs e)
        {
            input += 6;
            showInput();
        }

        private void seven_Click(object sender, EventArgs e)
        {
            input += 7;
            showInput();
        }

        private void eight_Click(object sender, EventArgs e)
        {
            input += 8;
            showInput();
        }

        private void nine_Click(object sender, EventArgs e)
        {
            input += 9;
            showInput();
        }
        private void four_Click(object sender, EventArgs e)
        {
            input += 4;
            showInput();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Display.Text = "";
            input = string.Empty;
            num1 = string.Empty;
            num2 = string.Empty;
            operation = 'N';
            numCount = 0;
        }

        private void doubleZero_Click(object sender, EventArgs e)
        {
            input += 0;
            input += 0;
            showInput();
        }

        private void zero_Click(object sender, EventArgs e)
        {
            input += 0;
            showInput();
        }
        private void showInput()
        {
            Display.Text = "";
            Display.Text = input;
        }

        private void Display_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (input.Length > 0)
            {
                input = input.Substring(0, input.Length - 1);
                showInput();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            numCount++;
            if (numCount >= 2)
            {
                equal_Click_1(sender, e);
            }
            num1 = input;
            operation = '/';
            input = string.Empty;
        }



        private void equal_Click_1(object sender, EventArgs e)
        {

            num2 = input;
            double first, second;
            double.TryParse(num1, out first);
            double.TryParse(num2, out second);

            if (numCount > 2)
            {
                first = answer;
            }

            if (operation == '+')
            {
                answer = first + second;
                Display.Text = answer.ToString();
            }
            else if (operation == '-')
            {
                answer = first - second;
                Display.Text = answer.ToString();
            }
            else if (operation == '*')
            {
                if (second == 0)
                {
                    answer = first;
                }
                if (first == 0)
                {
                    answer = second;
                }
                if (first != 0 && second != 0)
                {
                    answer = first * second;
                }
                Display.Text = answer.ToString();
            }
            else if (operation == '/')
            {
                if (second != 0)
                {
                    answer = first / second;
                    Display.Text = answer.ToString();
                }
                else
                {
                    Display.Text = "Error!";
                }

            }
            operation = 'N';
            numCount++;
        }

        private void Multiplication_Click(object sender, EventArgs e)
        {
            numCount++;
            if (numCount >= 2)
            {
                equal_Click_1(sender, e);
            }
            num1 = input;
            operation = '*';
            input = string.Empty;
        }

        private void substract_Click(object sender, EventArgs e)
        {
            numCount++;
            if (numCount >= 2)
            {
                equal_Click_1(sender, e);
            }
            num1 = input;
            operation = '-';
            input = string.Empty;
        }

        private void add_Click(object sender, EventArgs e)
        {
            numCount++;
            if (numCount >= 2)
            {
                equal_Click_1(sender, e);
            }
            num1 = input;
            operation = '+';
            input = string.Empty;
        }

        private void point_Click(object sender, EventArgs e)
        {
            if (!input.Contains("."))
            {
                input += ".";
                showInput();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double num;
            if (double.TryParse(input, out num))
            {
                num /= 100;
                input = num.ToString();
                showInput();
            }
        }
    }
}
